import tkinter as tk
from tkinter import *

import pandas as pd
from selenium import webdriver
from selenium.webdriver.common.by import By
import time as t
from selenium import webdriver
from matplotlib import font_manager, rc
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.keys import Keys
#한글 깨짐문제 해결 메소드
from matplotlib import font_manager, rc
import pandas as pd
from pandas import *
font_path = "C:/Windows/Fonts/NGULIM.TTF"
font = font_manager.FontProperties(fname=font_path).get_name()
rc('font', family=font)

# from  selenium import webdriver
# import time as t
# from selenium.webdriver.common.by import By



a=0
fsong = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
url ="https://www.melon.com/chart/age/index.htm?chartType=YE&chartGenre=KPOP&chartDate=2020"
fsong.get(url)
t.sleep(1)

fsong.execute_script('window.scrollTo(0, document.body.scrollHeight);') #스크롤 내리기

xpath1="/html/body/div/div[3]/div/div/div[4]/div/div[2]/div[1]/form/table/tbody/tr["
xpath3="]/td[4]/div/div/div[1]/span/strong/a"
xpath4="/html/body/div/div[3]/div/div/div[4]/div/div[2]/div[1]/form/table/tbody/tr["
xpath5="]/td[4]/div/div/div[2]/div[1]/a"
xpath6="/html/body/div/div[3]/div/div/div[4]/div/div[2]/div[1]/form/table/tbody/tr["
xpath7="]/td[5]/div/button/span[2]"

result1 = "/html/body/div/div[3]/div/div/div[4]/div/div[2]/div[1]/form/table/tbody/tr["
result2 = "]"



f= open("l1.csv",'w',encoding='UTF-8')
# f.write("2020년"+"\n")
f.write("곡명, 가수명, 좋아요,"+"\n")

for xpathn in range(1, 51):
    xpath100 = xpath1 + str(xpathn) + xpath3
    LO1 = fsong.find_element(By.XPATH, xpath100).text.replace(",","")
    print(LO1)


    xpath100 = xpath4 + str(xpathn) + xpath5
    LO2 = fsong.find_element(By.XPATH, xpath100).text.replace(",","")
    print(LO2)

    xpath100 = xpath6 + str(xpathn) + xpath7
    LO3 = fsong.find_element(By.XPATH, xpath100).text.replace(",","")
    print(LO3)
    f.write(LO1+','+LO2+','+LO3+"\n")
f.write("\n")

# f = pd.read_csv("l1.csv",  encoding='utf-8')
# csvWriter = csv.writer(f)
# csvWriter.writerow(LO3)
# for xpath2 in range(1, 50):
#     result1 ="/html/body/div[2]/div[3]/div/div/div[4]/div/div[2]/div[1]/form/table/tbody/tr["
#     result2 ="]/td[4]/div/div"
#     xpath100 = result1 + str(xpath2) + result2
#     LO = crolD.find_element(By.XPATH, xpath100).text




fsong.find_element_by_xpath("/html/body/div/div[3]/div/div/div[3]/div[3]/button[2]").click()
t.sleep(1)
# fsong.switch_to.frame("window")

fsong.execute_script('window.scrollTo(0, document.body.scrollHeight);')


# f.write("2021년"+"\n")
f.write("곡명, 가수명, 좋아요,"+"\n")

for xpathn in range(1, 51):
    xpath100 = xpath1 + str(xpathn) + xpath3
    LO1 = fsong.find_element(By.XPATH, xpath100).text.replace(",","")
    print(LO1)

    xpath100 = xpath4 + str(xpathn) + xpath5
    LO2 = fsong.find_element(By.XPATH, xpath100).text.replace(",","")
    print(LO2)

    xpath100 = xpath6 + str(xpathn) + xpath7
    LO3 = fsong.find_element(By.XPATH, xpath100).text.replace(",","")
    print(LO3)
    f.write(LO1+','+LO2+','+LO3+"\n")
f.write("\n")
f.close()
# while (True):
#     pass


data=read_csv("l1.csv",encoding='UTF-8')
print(data)
print(type(data))


import matplotlib.pyplot as plt
import numpy as np
font1={'family':'serif',
       'color':'b',
       'weight':'bold',
       'size':20
}


plt.rcParams["font.family"]='Malgun Gothic'
aciN=['부상자수','사고건수','사망자수']
value=[(a1[3]),(a1[4]),a1[5]]
colors=['#221123','#1313f2','#6313f2','#1313f2','#1313f2','#1312f2']
plt.ylim([0,10000])
plt.bar(aciN,value,color=colors)   #바에 x,y값지정

a= a1[0] ,a1[1], a1[2] +" 교통사고수 "

plt.title(a)
plt.ylabel("건수")
plt.xlabel("분류")
plt.show()


