# print("resultEle의값", ResultEle())
                # driver(driver.current_url)
                # print(txt2.get(i+1))
                # txt2.get = listbox.get(i + 1)

                # driver.get(driver.current_url)
                #     lista = []
                #     listb = []
                #     for i in range(len(txtDP1.get())):
                #         if txtDP1.get()[i] == txtDP2.get()[i]:
                #             lista.append(txtDP1.get()[i])
                #         elif txtDP1.get()[i] != txtDP2.get()[i]:
                #             listb.append(txtDP1.get()[i:len(txtDP1.get())])
                #             break
                #     result1 = listToString(lista)
                #     result2 = listToString(listb)
                #     for xpath2 in range(1, 100000000000):
                #         try:
                #             xpath100 = result1 + str(xpath2) + result2[1:]
                #             print(str(xpath2), ": %s" % driver.find_element(By.XPATH, xpath100).text)
                #             d1 = driver.find_element(By.XPATH, xpath100).text
                #             # mm2.deldata()
                #             mm2.inpelement('', '', d1, '')
                #         except:
                #             print("데이터 수집 완료")
                #             break
                # else:
                #     print("데이터 수집 완료")
                #     break
                # crolD.get(crolD.current_url)
                # print(crolD.current_url)



                # elif listbox.get(0) == "3.검색창 PATH값 : %s / 4.검색어 : %s" % (txtsearchpath.get(), txtsearch.get()):
                #     # driver.get(driver.current_url)
                #     elem = driver.find_element(By.XPATH, txtsearchpath.get())
                #     elem.send_keys(txtsearch.get())
                #     elem.send_keys(Keys.RETURN)
                #     t.sleep(3)
                #
                # elif listbox.get(0) == "5.데이터 수집 PATH값 1 : %s / 6.데이터 수집 PATH값 2: %s" % (txtDP1.get(), txtDP2.get()):
                #     # driver.get(driver.current_url)
                #     lista = []
                #     listb = []
                #     for i in range(len(txtDP1.get())):
                #         if txtDP1.get()[i] == txtDP2.get()[i]:
                #             lista.append(txtDP1.get()[i])
                #         elif txtDP1.get()[i] != txtDP2.get()[i]:
                #             listb.append(txtDP1.get()[i:len(txtDP1.get())])
                #             break
                #     result1 = listToString(lista)
                #     result2 = listToString(listb)
                #     for xpath2 in range(1, 100000000000):
                #         try:
                #             xpath100 = result1 + str(xpath2) + result2[1:]
                #             print(str(xpath2), ": %s" % driver.find_element(By.XPATH, xpath100).text)
                #             d1 = driver.find_element(By.XPATH, xpath100).text
                #             # mm2.deldata()
                #             mm2.inpelement('', '', d1, '')
                #         except:
                #             print("데이터 수집 완료")
                #             break
                # else:
                #     print("데이터 수집 완료")
                #     break

            # if listbox.get(0) == "3.검색창 PATH값 : %s / 4.검색어 : %s" % (txtsearchpath.get(), txtsearch.get()):
            #     driver.get(driver.current_url)
            #     elem = driver.find_element(By.XPATH, txtsearchpath.get())
            #     elem.send_keys(txtsearch.get())
            #     elem.send_keys(Keys.RETURN)
            #     t.sleep(3)
            # if listbox.get(0) == "5.데이터 수집 PATH값 1 : %s / 6.데이터 수집 PATH값 2: %s" % (txtDP1.get(), txtDP2.get()):
            #     driver.get(driver.current_url)
            #     lista = []
            #     listb = []
            #     for i in range(len(txtDP1.get())):
            #         if txtDP1.get()[i] == txtDP2.get()[i]:
            #             lista.append(txtDP1.get()[i])
            #         elif txtDP1.get()[i] != txtDP2.get()[i]:
            #             listb.append(txtDP1.get()[i:len(txtDP1.get())])
            #             break
            #     result1 = listToString(lista)
            #     result2 = listToString(listb)
            #     for xpath2 in range(1, 100000000000):
            #         try:
            #             xpath100 = result1 + str(xpath2) + result2[1:]
            #             print(str(xpath2), ": %s" % driver.find_element(By.XPATH, xpath100).text)
            #         except:
            #             print("데이터 수집 완료")
            #             break
            # # except NameError:
            # try:
            #     if listbox.get(0) == "5.데이터 수집 PATH값 1 : %s / 6.데이터 수집 PATH값 2: %s" % (txtDP1.get(), txtDP2.get()):
            #         driver.get(driver.current_url)
            #         lista = []
            #         listb = []
            #         for i in range(len(txtDP1.get())):
            #             if txtDP1.get()[i] == txtDP2.get()[i]:
            #                 lista.append(txtDP1.get()[i])
            #             elif txtDP1.get()[i] != txtDP2.get()[i]:
            #                 listb.append(txtDP1.get()[i:len(txtDP1.get())])
            #                 break
            #         result1 = listToString(lista)
            #         result2 = listToString(listb)
            #         for xpath2 in range(1, 100000000000):
            #             try:
            #                 xpath100 = result1 + str(xpath2) + result2[1:]
            #                 print(str(xpath2), ": %s" % driver.find_element(By.XPATH, xpath100).text)
            #             except:
            #                 print("데이터 수집 완료")
            #                 break
            # except:
            #     print("완료")
